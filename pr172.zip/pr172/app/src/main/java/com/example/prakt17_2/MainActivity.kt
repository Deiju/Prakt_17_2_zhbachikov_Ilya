package com.example.prakt17_2

import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    public var nam="acc"
    public var twoname="name"
    lateinit var login: EditText
    lateinit var pref: SharedPreferences
    lateinit var text: TextView
    lateinit var button: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        pref=getSharedPreferences(nam, MODE_PRIVATE)
        button=findViewById(R.id.button)

        if(pref.getBoolean("first",true)) {
            button.setOnClickListener{
                login = findViewById(R.id.edit)
                button=findViewById(R.id.button)
                var name = login.getText().toString()
                var save = pref.edit()
                save.putString(twoname, name)
                save.apply()
                login=findViewById(R.id.edit)
                text = findViewById(R.id.text)
                var names = pref.getString(twoname, "имя не введено")
                if (names=="")
                {
                    text.setText("Имя не введено")
                }
                else
                {
                    text.setText(names)
                    login = findViewById(R.id.edit)
                    login.setText(names)
                }
            }
        }
        else {
            login=findViewById(R.id.edit)
            login.setVisibility(View.INVISIBLE)
            button.setVisibility(View.INVISIBLE)
            text = findViewById(R.id.text)
            var names = pref.getString(twoname, "имя не введено")
            if (names=="")
            {
                text.setText("Имя не введено")
            }
            else
            {
                text.setText(names)
                login = findViewById(R.id.edit)
                login.setText(names)
            }
        }
        pref.edit().putBoolean("first",true).apply()
    }
}